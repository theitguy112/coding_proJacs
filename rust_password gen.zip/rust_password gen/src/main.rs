use rand::{rng,Rng};
//Rng is a trait in the rand crate.
fn main() {
    let length = 12;
    // orech yaani kmo bulbul

    let password = generate_password(length);
    println!("Generated password: {}", password);
}

fn generate_password(length: usize) -> String {
    // Define character sets
    let letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    let digits = "0123456789";
    let symbols = "!@#$%^&*()_-+=<>?";

    let all_chars = format!("{}{}{}", letters, digits, symbols);
    let chars: Vec<char> = all_chars.chars().collect();

    let mut rng = rng();

    // bone
    (0..length)
        .map(|_| chars[rng.random_range(0..chars.len())])
        .collect()
    //"|_|" za i dont give a fuck about value of element i just want to do this thing langth times
    //:)
}
