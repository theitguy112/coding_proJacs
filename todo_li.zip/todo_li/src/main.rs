use std::fs::File;
use std::io::Write;

fn main() {
    let mut task:Vec<Task> = Vec::new();
    add_task(&mut task, "Learn Rust".to_string());
    add_task(&mut task, "Build a CLI app".to_string());

    println!("Tasks:");
    list_tasks(&task);

    complete_task(&mut task, 0);

    println!("\nAfter completing task 0:");
    list_tasks(&task);

    save_tasks(&task);
}
struct Task {
    description: String,
    completed: bool,
}
fn add_task(tasks: &mut Vec<Task>, description:String ) {
    let task = Task {
        description,
        completed: false,
    };
    tasks.push(task);
}
fn list_tasks(tasks: &Vec<Task>) {
    for (i, task) in tasks.iter().enumerate() {
        let status = if task.completed { "✓" } else { " " };
        println!("{} [{}] {}", i, status, task.description);
    }
}
fn complete_task(tasks: &mut Vec<Task>, index: usize) {
    if let Some(task) = tasks.get_mut(index) {
        task.completed = true;
    } else {
        println!("Task not found");
    }
}
fn save_tasks(tasks: &Vec<Task>) {
    let mut file = File::create("tasks.txt").expect("Unable to create file");

    for task in tasks {
        let line = format!("{},{}\n", task.completed, task.description);
        file.write_all(line.as_bytes()).unwrap();
    }
}

